package csumb.flashcards;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

import csumb.flashcards.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private AppDb flashcardDb;
    private List<Flashcard> flashcards;

    private List<Flashcard> flashcardList;

    private static final Random RANDOM = new Random();
    private int currentFlashcardId;
    private int cardsRemaining;
    private Flashcard currentFlashcard;
    private Toast currentAnswerToast;
    private Button markCorrectButton;
    private Button showAnswerButton;
    private Button randomCardButton;
    private Button resetCardsButton;
    private boolean resetting = false;


    private ActivityMainBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);
        flashcardDb = AppDb.getInstance(this);
        markCorrectButton = binding.markCorrectButton;
        markCorrectButton.setOnClickListener(v -> markComplete());
        showAnswerButton = binding.showAnswerButton;
        showAnswerButton.setOnClickListener(v -> showAnswer());
        randomCardButton = binding.randomCardButton;
        randomCardButton.setOnClickListener(v -> pickRandomFlashcard());
        resetCardsButton = binding.resetCardsButton;
        resetCardsButton.setOnClickListener(v -> resetCards());
        binding.addCardButton.setOnClickListener(v -> addCard(v));
        // ORDER BELOW CANNOT CHANGE
        resetCards();
        pickRandomFlashcard();
        // ORDER ABOVE CANNOT CHANGE
    }

    public void addCard(View v) {
        Intent intent = new Intent(this, NewCardActivity.class);
        startActivity(intent);

        //reinitialize the database and update our list
        FlashcardDAO flashcardDAO = flashcardDb.getFlashcardDAO();
        flashcards = flashcardDAO.listFlashcard();
        flashcardList = flashcards;
        pickRandomFlashcard();
        cardsRemaining++;
        updateRandomButton();
    }

    private void loadQuestions() {
        FlashcardDAO flashcardDAO = flashcardDb.getFlashcardDAO();
        Flashcard a = new Flashcard(this, R.string.question_compiler, R.string.answer_compiler);
        Flashcard b = new Flashcard(this, R.string.question_https, R.string.answer_https);
        Flashcard c = new Flashcard(this, R.string.question_os, R.string.answer_os);
        Flashcard d = new Flashcard(this, R.string.question_rdbms, R.string.answer_rdbms);
        if(resetting = true){
            flashcardDAO.deleteByAnswer(R.string.question_compiler);
            flashcardDAO.deleteByAnswer(R.string.question_https);
            flashcardDAO.deleteByAnswer(R.string.question_os);
            flashcardDAO.deleteByAnswer(R.string.question_rdbms);
        }
        //Adding default flashcards
        flashcards = flashcardDAO.listFlashcard();
        if(flashcards == null || flashcards.size() == 0){
            flashcardDAO.insertFlashcard(a);
            flashcardDAO.insertFlashcard(b);
            flashcardDAO.insertFlashcard(c);
            flashcardDAO.insertFlashcard(d);
        }
        flashcardList = flashcardDAO.listFlashcard();
        resetting = false;
    }

    @SuppressLint("SetTextI18n")
    private void resetCards() {
        resetting = true;
        if(flashcardList == null || flashcardList.size() == 0) {
            loadQuestions();
        } else {
            for (Flashcard f : flashcardList) {
                f.setComplete(false);
            }
            toggleButtons(true);
            pickRandomFlashcard();
        }
        cardsRemaining = flashcardList.size();
        updateRandomButton();
    }

    private void updateRandomButton() {
        randomCardButton.setText(getString(R.string.random_button_text, cardsRemaining));
    }

    private void toggleButtons(boolean enable) {
        markCorrectButton.setEnabled(enable);
        showAnswerButton.setEnabled(enable);
        randomCardButton.setEnabled(enable);
    }

    private void showAnswer() {
        if(currentAnswerToast != null) {
            currentAnswerToast.show();
        } else{
            Toast.makeText(getApplicationContext(), ("WTF?!"), Toast.LENGTH_LONG).show();
        }
    }
    private void markComplete() {
        if(cardsRemaining == 1 && currentFlashcard != null) {
            // turn off mark correct, show answer, and random card buttons
            toggleButtons(false);
            binding.questionTextView.setText(R.string.cards_finished_text);

        } else {
            currentFlashcard.setComplete(true);
            FlashcardDAO flashcardDAO = flashcardDb.getFlashcardDAO();
            Flashcard update = currentFlashcard;
            flashcardDAO.updateFlashcard(update);

            pickRandomFlashcard();
        }
        cardsRemaining--;
        updateRandomButton();
    }

    private void pickRandomFlashcard() {
        if(cardsRemaining == 1) {
            return;
        }
        int random;
        // can't look at the same card twice in a row unless it's the last card
        // and can't look at complete cards
        do {
            random = RANDOM.nextInt(flashcardList.size());
        } while (random == currentFlashcardId ||
                flashcardList.get(random).isComplete());
        currentFlashcardId = random;
        currentFlashcard = flashcardList.get(currentFlashcardId);
        binding.questionTextView.setText(currentFlashcard.getQuestion());
        currentAnswerToast = Toast.makeText(getApplicationContext(),
                currentFlashcard.getAnswer(), Toast.LENGTH_LONG);
    }
}