package csumb.flashcards;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

//Dao accomplishes CRUD for us
//Create, Read, Update, Delete
@Dao
public interface FlashcardDAO {
    @Insert
    void insertFlashcard(Flashcard flashcard);
    @Update
    void updateFlashcard(Flashcard flashcard);
    @Delete
    void deleteFlashcard(Flashcard flashcard);
    @Query("SELECT * FROM flashcard")
    List<Flashcard> listFlashcard();

    @Query("delete from flashcard where answer = :answer")
    void deleteByAnswer(int answer);

    @Query("delete from flashcard where question = :question")
    void deleteByQuestion(String question);

    @Query("delete from flashcard where uid = :id")
    void deleteByID(int id);
}
